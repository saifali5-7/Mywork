import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns

# 1. Load the dataset
df = pd.read_excel('Balochistan Population Dataset.xlsx')
sns.set_theme(style="whitegrid")

# --- 0. DESCRIPTIVE STATISTICS (PNG TABLE GENERATION) ---
# Calculate stats and round to 2 decimal places
desc_stats = df[['Total', 'Male', 'Female']].describe().round(2)
table_df = desc_stats.reset_index().rename(columns={'index': 'Statistic'})

# Create a figure for the table
fig, ax = plt.subplots(figsize=(10, 4))
ax.axis('off')
table = ax.table(cellText=table_df.values, 
                 colLabels=table_df.columns, 
                 loc='center', 
                 cellLoc='center')

# Style the table
table.auto_set_font_size(False)
table.set_fontsize(12)
table.scale(1.2, 2.2)

# Apply header color
for (row, col), cell in table.get_celld().items():
    if row == 0:
        cell.set_text_props(weight='bold', color='white')
        cell.set_facecolor('#4c72b0')

plt.title('Descriptive Statistics Summary', fontsize=16, weight='bold', pad=20)
plt.savefig('0_Descriptive_Statistics.png', dpi=300, bbox_inches='tight')
plt.close()

# --- CHAPTER 4: CLEAN EDA CHART SET ---

# 1. HISTOGRAM: Overall Distribution
plt.figure(figsize=(10, 6))
sns.histplot(df['Total'], bins=30, kde=True, color='royalblue')
plt.title('1. Distribution of Population Totals', fontsize=14)
plt.xlabel('Total Population Value')
plt.ylabel('Frequency')
plt.savefig('1_Histogram.png', dpi=300)
plt.close()

# 2. BAR CHART: Indicator-wise Total
plt.figure(figsize=(12, 6))
indicator_totals = df.groupby('Indicator')['Total'].sum().sort_values(ascending=True)
indicator_totals.plot(kind='barh', color='teal')
plt.title('2. Employment Structure: Total by Indicator', fontsize=14)
plt.xlabel('Total Population')
plt.ylabel('Indicator Type')
plt.ticklabel_format(style='plain', axis='x')
plt.savefig('2_Indicator_Bar.png', dpi=300, bbox_inches='tight')
plt.close()

# 3. BAR CHART: Rural vs Urban Comparison
plt.figure(figsize=(8, 6))
df.groupby('Area Type')['Total'].sum().plot(kind='bar', color=['#ffa600', '#003f5c'])
plt.title('3. Rural vs Urban Population Comparison', fontsize=14)
plt.xlabel('Area Type')
plt.ylabel('Total Population')
plt.xticks(rotation=0)
plt.ticklabel_format(style='plain', axis='y')
plt.savefig('3_Area_Comparison.png', dpi=300)
plt.close()

# 4. GROUPED BAR CHART: Gender by Area Type
gender_area = df.groupby('Area Type')[['Male', 'Female']].sum()
ax = gender_area.plot(kind='bar', figsize=(10, 6), color=['#bc5090', '#58508d'])
plt.title('4. Gender Distribution Across Rural & Urban Areas', fontsize=14)
plt.ylabel('Population Count')
plt.xlabel('Area Type')
plt.xticks(rotation=0)
plt.ticklabel_format(style='plain', axis='y')
plt.legend(title='Gender')
plt.savefig('4_Gender_Area_Grouped.png', dpi=300)
plt.close()

# 5. SCATTER PLOT: Male vs Female (Relationship)
plt.figure(figsize=(10, 6))
sns.scatterplot(data=df, x='Male', y='Female', hue='Area Type', palette='Set1', s=60, alpha=0.6)
plt.title('5. Scatter Plot: Male vs Female Participation', fontsize=14)
plt.savefig('5_Scatter_Male_Female.png', dpi=300)
plt.close()

# 6. HEATMAP: Correlation Matrix
plt.figure(figsize=(8, 6))
corr_matrix = df[['Total', 'Male', 'Female']].corr()
sns.heatmap(corr_matrix, annot=True, cmap='YlGnBu', fmt=".2f")
plt.title('6. Correlation Heatmap: Statistical Relationship', fontsize=14)
plt.savefig('6_Correlation_Heatmap.png', dpi=300)
plt.close()

print("Process Complete: 7 Images generated (including Descriptive Stats Table).")